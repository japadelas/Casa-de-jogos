import React from 'react'

const jogos = [
  { nome: 'Triguinho' },
  { nome: 'Dragão' },
  { nome: 'Coelhinho' },
  { nome: 'Touro' },
  { nome: 'Aviator' }
]

export default function App() {
  return (
    <div style={{ background: '#111', color: 'white', minHeight: '100vh', padding: '2rem' }}>
      <h1 style={{ textAlign: 'center', fontSize: '2rem' }}>Casa de Jogos</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginTop: '2rem' }}>
        {jogos.map(jogo => (
          <div key={jogo.nome} style={{ background: '#222', padding: '1rem', borderRadius: '8px', textAlign: 'center' }}>
            <h2>{jogo.nome}</h2>
            <button style={{ marginTop: '1rem', padding: '0.5rem 1rem', background: '#444', color: 'white', border: 'none', borderRadius: '4px' }}>Jogar</button>
          </div>
        ))}
      </div>
    </div>
  )
}
